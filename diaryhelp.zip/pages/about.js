import React from 'react'

const about = () => {
  return (
    <div>
      
    </div>
  )
}

export default about
