import React from 'react'

const customeradd = () => {
  return (
    <div className='text-black'>
      hello
    </div>
  )
}

export default customeradd
